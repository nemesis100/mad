package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


        ListView listView;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            listView=findViewById(R.id.lv);
            Company company1=new Company("Adode","California","$4.07 billions");
            Company company2=new Company("Amazon","Washington","$386 billions");
            Company company3=new Company("Google","California","$181.6 billions");
            Company company4=new Company("Facebook","California","$181.6 billions");
            Company company5=new Company("Cisco","California","$181.6 billions");
            ArrayList<Company> companies=new ArrayList<>();
            companies.add(company1);
            companies.add(company2);
            companies.add(company3);
            companies.add(company4);
            companies.add(company5);
            CompanyAdapter adapter=new
                    CompanyAdapter(MainActivity.this,R.layout.listview,companies);
            listView.setAdapter(adapter);

        }
}