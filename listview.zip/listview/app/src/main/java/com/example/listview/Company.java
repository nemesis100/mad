package com.example.listview;

public class Company {
    private String name;
    private String HQ;
    private String Annual_rev;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getHQ() {
        return HQ;
    }
    public void setHQ(String HQ) {
        this.HQ = HQ;
    }
    public String getAnnual_rev() {
        return Annual_rev;
    }
    public void setAnnual_rev(String annual_rev) {
        Annual_rev = annual_rev;
    }
    public Company(String name, String HQ, String annual_rev) {
        this.name = name;
        this.HQ = HQ;
        Annual_rev = annual_rev;
    }


}
