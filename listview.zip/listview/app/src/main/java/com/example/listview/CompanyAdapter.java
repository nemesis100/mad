package com.example.listview;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class CompanyAdapter extends ArrayAdapter<Company> {
    private Context context;
    int mresource;
    public CompanyAdapter(Context context, int resource, ArrayList<Company>
            objects) {
        super(context, resource, objects);
        this.context = context;
        mresource=resource;
    }
    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String name=getItem(position).getName();
        String HQ=getItem(position).getHQ();
        String Annual_rev=getItem(position).getAnnual_rev();
        Company company=new Company(name,HQ,Annual_rev);
        LayoutInflater inflater=LayoutInflater.from(context);
        convertView=inflater.inflate(mresource,parent,false);
        TextView tv=(TextView)convertView.findViewById(R.id.tv);
        TextView tv1=(TextView)convertView.findViewById(R.id.tv1);
        TextView tv2=(TextView)convertView.findViewById(R.id.tv2);
        tv.setText(name);
        tv1.setText(HQ);
        tv2.setText(Annual_rev);
        return convertView;
    }
}
