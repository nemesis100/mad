package com.example.secondact;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    TextView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        view = findViewById(R.id.view);

        Intent myIntent = getIntent();
        String fname = myIntent.getStringExtra("fn");
        String lname = myIntent.getStringExtra("ln");
        String rollnumber = myIntent.getStringExtra("roll_number");
        view.setText("Welcome! " + fname + " " + lname + " " + "\nRoll Number: " + rollnumber);

    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this,"back button disabled", Toast.LENGTH_LONG).show();
    }
}