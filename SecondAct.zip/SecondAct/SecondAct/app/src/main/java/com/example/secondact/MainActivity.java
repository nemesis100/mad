package com.example.secondact;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.os.Bundle;

public class
MainActivity extends AppCompatActivity {

    EditText fn, ln, rollno;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fn = findViewById(R.id.fn);
        ln = findViewById(R.id.ln);
        rollno = findViewById(R.id.roll_number);

        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("fn",fn.getText().toString());
                intent.putExtra("ln",ln.getText().toString());
                intent.putExtra("roll_number",rollno.getText().toString());
                startActivity(intent);
            }
        });
    }

}